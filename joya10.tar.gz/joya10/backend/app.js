const express = require("express");
const mongoose = require("mongoose");
const userRoutes = require("./routes/api");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static("joya99-copy"));

// Routes
app.use("/api", userRoutes);

// Connect to MongoDB
mongoose
  .connect("mongodb://localhost:27017/joya99db", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(PORT, () => {
      console.log(`Backend running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
  });
