document.addEventListener("DOMContentLoaded", () => {
  console.log("Joya99 Live Frontend Loaded");
});
